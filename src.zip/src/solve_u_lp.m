function [u, flag] = solve_u_lp(f)

    u = f < 0;
    flag = 1;
    
end


