function printSeparator(char)

line = repmat(char, 1, 80);
disp(line);

end